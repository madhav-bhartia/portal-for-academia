from app.database import create_db_and_tables, engine
from sqlmodel import Session
from app.models import (
    User, Role, Internship, Job, Project, Certificate,
    Assessment, AssessmentResult, TrainingProgram,
    AcademicOpportunity, AcademicOpportunityType
)
from app.auth import hash_password
from datetime import datetime, timedelta

def seed_data():
    # 1. Ensure tables exist
    create_db_and_tables()
    
    with Session(engine) as session:
        # Check if database already has users
        if session.query(User).first():
            print("Database already contains data! Skipping seed.")
            return

        print("Seeding database with test data...")

        # 2. Create Users
        student = User(
            name="Alice Student", 
            email="alice@student.com", 
            hashed_password=hash_password("password"), 
            role=Role.student, 
            skills="python,react,sql", 
            bio="Computer Science major looking for software engineering roles."
        )
        industry = User(
            name="TechCorp Industries", 
            email="hr@techcorp.com", 
            hashed_password=hash_password("password"), 
            role=Role.industry, 
            company_name="TechCorp Inc."
        )
        academician = User(
            name="Dr. Alan Turing", 
            email="alan@university.edu", 
            hashed_password=hash_password("password"), 
            role=Role.academician
        )
        institution = User(
            name="Global Tech Institute", 
            email="admin@gti.edu", 
            hashed_password=hash_password("password"), 
            role=Role.institution
        )
        
        session.add_all([student, industry, academician, institution])
        session.commit() # Commit to generate IDs

        # 3. Create Jobs & Internships
        job = Job(
            industry_id=industry.id, 
            title="Junior Frontend Developer", 
            description="Looking for a React developer to join our core product team.", 
            required_skills="react,javascript,css"
        )
        internship = Internship(
            industry_id=industry.id, 
            title="Data Science Intern", 
            description="Work with big data pipelines and machine learning models.", 
            required_skills="python,sql,pandas"
        )
        session.add_all([job, internship])

        # 4. Create Portfolio Data for Student
        project = Project(
            student_id=student.id, 
            title="AI Chatbot Assistant", 
            description="A support chatbot built using Python and NLP.", 
            link="https://github.com/alice/chatbot"
        )
        cert = Certificate(
            student_id=student.id, 
            title="Advanced React Concepts", 
            issuer="Coursera", 
            issue_date=datetime.utcnow() - timedelta(days=45)
        )
        session.add_all([project, cert])

        # 5. Create Assessments
        assessment1 = Assessment(
            title="Python Core Programming", 
            description="Test your knowledge of Python data structures and algorithms.", 
            skill_category="python"
        )
        assessment2 = Assessment(
            title="Frontend Web Development", 
            description="HTML, CSS, and basic JavaScript concepts.", 
            skill_category="javascript"
        )
        session.add_all([assessment1, assessment2])
        session.commit()

        # 6. Create Assessment Result
        result = AssessmentResult(
            student_id=student.id, 
            assessment_id=assessment1.id, 
            score=88
        )
        session.add(result)

        # 7. Create Training Programs
        training = TrainingProgram(
            industry_id=industry.id, 
            title="TechCorp React Bootcamp", 
            description="A 4-week intensive bootcamp covering modern React.", 
            skills_covered="react,hooks,redux", 
            link="https://techcorp.com/bootcamp"
        )
        session.add(training)

        # 8. Create Academic Opportunities
        academic_opp = AcademicOpportunity(
            creator_id=industry.id, 
            type=AcademicOpportunityType.research, 
            title="AI in Healthcare Research", 
            description="Looking for professors to collaborate on predictive health models."
        )
        session.add(academic_opp)

        session.commit()
        print("Done! Seeded 1 Student, 1 Industry, 1 Academician, 1 Institution, and associated data.")
        print("Login with 'alice@student.com' / 'password' to test the student view.")

if __name__ == "__main__":
    seed_data()
